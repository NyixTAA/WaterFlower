import React, { useState, useEffect } from 'react';
import { Text, View, Image, ImageBackground } from "react-native";
import { styles } from "./styles";
import { Link } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { ProgressBar } from 'react-native-paper';
import { colors } from '../styles/colors';

export default function Home() {
    const [umidade, setUmidade] = useState(0);

async function receberDados() {
    try {
        const res = await fetch("http://192.168.137.182/dados");
        const data = await res.text();  
        
        console.log("Dados recebidos:", data);  

        const umidadeSensor = parseInt(data, 10);  
        console.log("Valor do sensor de umidade:", umidadeSensor);  

        if (isNaN(umidadeSensor)) {
            console.error("Erro: o valor recebido não é um número válido");
            return;
        }
        const umidadeNormalizada = umidadeSensor / 1024.0;
        console.log("Umidade normalizada:", umidadeNormalizada); 
        setUmidade(umidadeNormalizada);
    } catch (error) {
        console.error("Erro ao receber dados:", error);
    }
}
    useEffect(() => {
        receberDados();
       
    }, []); 
    return (
        <ImageBackground source={require('../../../assets/images/BG_3.png')}
            resizeMode="cover"
            style={styles.backgroundImage_select}>
            <StatusBar hidden={true} />
            <View style={styles.baia_menu}>
                <View style={{ flexDirection: 'row', gap: 15, alignItems: 'center' }}>
                    <Link href={'../select'}>
                        <Image style={{ width: 10, height: 18, padding: 5 }} source={require('../../../assets/icons/back.png')} />
                    </Link>
                    <View style={styles.baia_selecionada}>
                        <View style={{ flexDirection: 'row', gap: 4 }}>
                            <Text style={styles.baia_name}>Baia 1</Text>
                        </View>
                        <Text style={styles.baia_ip}>IP: 000.121.123</Text>
                    </View>
                </View>
                <Image style={{ width: 26, height: 32 }} source={require('../../../assets/icons/pot.png')} />
            </View>
            <View style={styles.container_pai_home}>
                <View style={styles.container_flower_home}>
                    <Image source={require('../../../assets/images/icon.png')} style={styles.flower_2} resizeMode='contain' />
                    <Text style={styles.title_home}>Gerencie a <Text style={styles.sub_home}>Baia 1</Text></Text>
                </View>
            </View>
            <View style={styles.tabs_container}>
                <View style={{ flexDirection: 'row', gap: 15 }}>
                    <View style={styles.config_tab2}>
                        <View style={styles.sensor_tab_color2} />
                        <Link style={styles.backicon} href={'../homepage'}>
                            <Image source={require('../../../assets/icons/backalt.png')} />
                        </Link>
                        <View style={{ alignItems: 'center' }}>
                            <Image style={styles.sensor_icon} source={require('../../../assets/icons/sensor.png')} />
                            <Text style={styles.config_text2}>Sensores</Text>
                        </View>
                        <View style={styles.sensor_tab_container}>
                            <Text style={styles.sensor_tab_container_text}>Sensor de umidade:</Text>
                            {/* Barra de progresso com o valor normalizado */}
                            <ProgressBar progress={umidade} color={colors.ui[300]} style={styles.progress_bar} />
                            <Text style={styles.sensor_tab_container_text}>Nível IUV:</Text>
                            <ProgressBar progress={0.5} color={colors.ui[600]} style={styles.progress_bar} />
                            <View style={{ flexDirection: 'row', gap: 5 }}>
                                <Text style={styles.sensor_tab_container_text}>Sensor UV:</Text>
                                <Text style={styles.sensor_status_text}>OK</Text>
                            </View>
                            <View style={{ flexDirection: 'row', gap: 5 }}>
                                <Text style={styles.sensor_tab_container_text}>Sensor de umidade:</Text>
                                <Text style={styles.sensor_status_text}>OK</Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>


            <View style={styles.sensor_text_container} />
            <Text style={styles.watermark}>WaterFlower inc.</Text>
        </ImageBackground>
    );
}
